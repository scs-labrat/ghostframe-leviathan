from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

@app.route('/query', methods=['POST'])
def query():
    data = request.json
    user = data.get("user")
    password = data.get("password")
    sql = data.get("sql")
    return jsonify({"message": f"Simulated REST call by {user}: {sql}"})

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8082)
