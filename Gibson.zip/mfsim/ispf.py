import os
import time
import random
import logging
from enum import Enum

# Setup logging
logging.basicConfig(
    level=logging.DEBUG,
    format='[%(asctime)s] %(levelname)s: %(message)s',
    filename='ispf.log'
)
logger = logging.getLogger("ISPFSession")

class ScreenState(Enum):
    MAIN_MENU = 1
    EDITOR = 2
    UTILITIES = 3
    DATASET_UTILITY = 4
    MOVE_COPY = 5
    DATASET_LIST = 6
    SDSF = 7
    SDSF_DA = 8
    SDSF_APF = 9
    ALLOCATE = 10

class ISPFSession:
    def __init__(self, conn, username):
        self.conn = conn
        self.username = username.upper()
        self.state = ScreenState.MAIN_MENU
        self.editor_content = []
        self.editor_filename = f"{self.username}.WORKFILE.TEXT"
        self.datasets = self._generate_datasets()
        self.current_dslist_position = 0
        self.dslist_page_size = 10
        self.current_line = 0
        
        # Prepare per-user directory for persistence
        self.user_dir = os.path.join(os.getcwd(), "userdata", self.username)
        os.makedirs(self.user_dir, exist_ok=True)

        self.show_banner()
        logger.info(f"ISPF session started for {self.username}")

    def _generate_datasets(self):
        return [
            (f"{self.username}.REXX.LIB", "12K", "PO", "03/15/24"),
            (f"{self.username}.CLIST.LIB", "8K", "PO", "03/10/24"),
            (f"{self.username}.JCL.SOURCE", "32K", "PO", "04/01/24"),
            (f"{self.username}.ISPF.PANELS", "4K", "PO", "03/20/24"),
            (f"{self.username}.LOADLIB", "256K", "PO", "04/05/24"),
            (f"{self.username}.EDIT.TEMP", "1K", "PS", "04/10/24"),
            ("SYS1.LINKLIB", "1024K", "PO", "01/01/70"),
            ("SYS1.PARMLIB", "512K", "PO", "01/01/70"),
        ]

    def send(self, text):
        try:
            self.conn.sendall(text.encode('utf-8'))
        except:
            raise SystemExit

    def clear(self):
        self.conn.sendall(b"\033[2J\033[H")

    def get_input(self, prompt=""):
        self.send(prompt)
        data = b""
        while True:
            try:
                c = self.conn.recv(1)
                if not c:
                    raise SystemExit
                if c in (b"\r", b"\n"):
                    break
                data += c
            except:
                raise SystemExit
        return data.decode('utf-8').strip().upper()

    def show_banner(self):
        self.clear()
        banner = (
            "                           I S P F / P D F   S Y S T E M   S E R V I C E S\n"
            "\n"
            f"                              {time.strftime('%H:%M:%S')} {time.strftime('%m/%d/%y')}\n"
            "\n"
            f"                          USERID - {self.username.ljust(8)}\n"
        )
        self.send(banner)
        time.sleep(1)

    def show_main_menu(self):
        self.clear()
        menu = f"""
Menu  Utilities  Compilers  Options  Status  Help
────────────────────────────────────────────────────────────────────────────────
                            ISPF Primary Option Menu

 0  Settings      Terminal and user parameters            Screen. . : 1
 1  View          Display source data or listings         Language. : ENGLISH
 2  Edit          Create or change source data            Appl ID . : ISR
 3  Utilities     Perform utility functions               TSO logon : {self.username}
 4  Foreground    Interactive language processing         TSO USER  : {self.username}
 5  Batch         Submit job for language processing      System ID : PROD
 6  Command       Enter TSO or Workstation commands       MVS acct. : ACCT#
 7  Dialog Test   Perform dialog testing                  Release . : ISPF 8.1
 9  IBM Products  IBM program development products
S SDSF           System Display and Search Facility

      Enter X to Terminate using log/list defaults

Time: {time.strftime('%H:%M:%S')}                                        Date: {time.strftime('%Y-%m-%d')}
Option ===> """
        self.send(menu)
        return self.get_input()

    def show_editor(self):
        self.clear()
        filepath = os.path.join(self.user_dir, self.editor_filename)
        
        # Load file if exists
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                self.editor_content = f.read().splitlines()
        else:
            self.editor_content = ["", "", "", "", ""]  # Start with 5 blank lines

        while True:
            self.clear()
            self.send(f"EDIT ---- {self.editor_filename} ---- LINE {self.current_line+1} OF {len(self.editor_content)}\n")
            self.send("COMMAND ===>                                                  SCROLL ===> PAGE\n")
            
            # Show current page of content
            start_line = max(0, self.current_line - 5)
            end_line = min(len(self.editor_content), self.current_line + 15)
            
            for i in range(start_line, end_line):
                line_num = str(i+1).rjust(6)
                self.send(f"{line_num} {self.editor_content[i]}\n")
            
            self.send("\nEnter C D I E or line command\n")
            cmd = self.get_input("===> ")
            
            if cmd == "F3":
                break
            elif cmd.startswith("SAVE"):
                with open(filepath, 'w') as f:
                    f.write("\n".join(self.editor_content))
                self.send("\nFile saved.\n")
                time.sleep(1)
            elif cmd.startswith("CANCEL"):
                self.editor_content = []
                self.send("\nChanges discarded.\n")
                time.sleep(1)
                break
            elif cmd == "D":
                if self.current_line < len(self.editor_content):
                    del self.editor_content[self.current_line]
                    if self.current_line >= len(self.editor_content):
                        self.current_line = max(0, len(self.editor_content) - 1)
            elif cmd == "I":
                new_line = self.get_input("Enter text to insert: ")
                self.editor_content.insert(self.current_line, new_line)
                self.current_line += 1
            elif cmd == "E":
                if self.current_line < len(self.editor_content):
                    edit_text = self.get_input(f"Edit line {self.current_line+1}: ")
                    self.editor_content[self.current_line] = edit_text
            elif cmd == "UP":
                self.current_line = max(0, self.current_line - 1)
            elif cmd == "DOWN":
                self.current_line = min(len(self.editor_content) - 1, self.current_line + 1)
            elif cmd.isdigit():
                line_num = int(cmd) - 1
                if 0 <= line_num < len(self.editor_content):
                    self.current_line = line_num

    def show_utilities(self):
        self.clear()
        menu = """
-------------------------  Utility Selection Menu  ----------------------------

  1  Library     - Library utility
  2  Dataset     - Data set utility (3.2)
  3  Move/Copy   - Move, copy members or data sets (3.3)
  4  Dslist      - Data set list utility (3.4)
  7  VTOC        - Display DISK Volume Table Of Contents
S SDSF           System Display and Search Facility

F3=Exit

Option ===> """
        self.send(menu)
        choice = self.get_input()
        
        if choice == "F3":
            self.state = ScreenState.MAIN_MENU
        elif choice == "2":
            self.show_dataset_utility()
        elif choice == "3":
            self.show_move_copy()
        elif choice == "4":
            self.show_dataset_list()
        elif choice == "S":
            self.show_sdsf()

    def show_sdsf(self):
        while True:
            self.clear()
            self.send("""
-------------------------- SDSF PRIMARY OPTION MENU --------------------------

 DA - Display Active Users
 I  - Input Queue
 O  - Output Queue
 ST - Status
 APF - APF Authorized Libraries

F3=Exit

Option ===> """)
            choice = self.get_input()
            
            if choice == "F3":
                self.state = ScreenState.UTILITIES
                break
            elif choice == "DA":
                self.show_sdsf_da()
            elif choice == "APF":
                self.show_sdsf_apf()

    def show_sdsf_da(self):
        self.clear()
        self.send("""
COMMAND ===>                                                  SCROLL ===> PAGE
 S Q JOBNAME  JOBIDENT QUEUE  EXEC STATUS   RECORDS STEPNAME PROCSTEP   CPU-TIME
 ' ' MASTER   S0W1     STARTED 00:00:00     0                         0.00
 ' ' OPER1    TSU0001  ACTIVE  08:15:23     5                         1.23  
 ' ' OPER2    TSU0002  ACTIVE  08:20:45     3                         0.87
 ' ' DB2ADM   TSU0003  ACTIVE  08:25:12     7                         2.15
 ' ' CICSADM  BATCH001 ACTIVE  07:30:00     1                         5.12
 ' ' IMSADM   BATCH002 ACTIVE  07:45:00     1                         3.45
""")
        self.get_input("\nPress Enter to continue...")

    def show_sdsf_apf(self):
        self.clear()
        self.send("""
COMMAND ===>                                                  SCROLL ===> PAGE
 APF Authorized Libraries:
    SYS1.LINKLIB
    SYS1.SVCLIB
    SYS1.LPALIB
    SYS1.MIGLIB
    SYS1.NUCLEUS
    SYS1.PROCLIB
    SYS1.PARMLIB
    SYS1.CMDLIB
""")
        self.get_input("\nPress Enter to continue...")

    def show_dataset_utility(self):
        while True:
            self.clear()
            self.send("""
------------------------------ DATASET UTILITY ------------------------------
Command ===> 

    A - Allocate new dataset
    D - Delete dataset
    R - Rename dataset
    C - Catalog dataset
    U - Uncatalog dataset
    I - Dataset information

F3=Exit

Option ===> """)
            choice = self.get_input()
            
            if choice == "F3":
                self.state = ScreenState.UTILITIES
                break
            elif choice == "A":
                self.show_allocate()
            elif choice == "I":
                self.show_dataset_info()

    def show_allocate(self):
        self.clear()
        self.send("""
----------------------------- ALLOCATE DATASET -----------------------------
Command ===> 

Dataset name: 
Volume serial: 
Organization (PS/PO): 
Record format (FB/FBA/VB/VBA): 
Record length: 
Block size: 

F1=Help  F3=Exit  F7=Backward  F8=Forward
""")
        
        dsname = self.get_input("\nEnter dataset name: ")
        volser = self.get_input("Enter volume serial: ")
        org = self.get_input("Enter organization (PS/PO): ")
        recfm = self.get_input("Enter record format: ")
        lrecl = self.get_input("Enter record length: ")
        blksize = self.get_input("Enter block size: ")
        
        if dsname and org in ("PS", "PO"):
            self.datasets.append((dsname, "10K", org, time.strftime("%m/%d/%y")))
            self.send(f"\nDataset {dsname} allocated successfully.\n")
            time.sleep(2)
        else:
            self.send("\nInvalid allocation parameters.\n")
            time.sleep(2)

    def show_dataset_info(self):
        self.clear()
        self.send("\nEnter dataset name: ")
        dsname = self.get_input()
        
        found = None
        for ds in self.datasets:
            if ds[0] == dsname:
                found = ds
                break
        
        if found:
            self.send(f"""
Dataset Information:
  Name: {found[0]}
  Size: {found[1]}
  Org: {found[2]}
  Created: {found[3]}
  Record Format: FB
  Record Length: 80
  Block Size: 3120
""")
        else:
            self.send("\nDataset not found.\n")
        
        self.get_input("\nPress Enter to continue...")

    def show_move_copy(self):
        self.clear()
        self.send("""
----------------------------- MOVE/COPY UTILITY -----------------------------
Command ===> 

Source Data Set Name . . 
Target Data Set Name . . 
Replace like-named members . . . . . 

F1=Help  F3=Exit  F7=Backward  F8=Forward
""")
        self.get_input()
        self.state = ScreenState.UTILITIES

    def show_dataset_list(self):
        self.clear()
        self.send("""
-------------------------------- DSLIST --------------------------------
Command ===> 

Data Set Name Prefix . . 
Volume Serial . . . . . 

F1=Help  F3=Exit  F7=Backward  F8=Forward
""")
        self.get_input()
        self.state = ScreenState.UTILITIES

    def run(self):
        try:
            while True:
                if self.state == ScreenState.MAIN_MENU:
                    choice = self.show_main_menu()
                    if choice == "2":
                        self.show_editor()
                    elif choice == "3":
                        self.state = ScreenState.UTILITIES
                    elif choice == "S":
                        self.show_sdsf()
                    elif choice == "X":
                        break
                
                elif self.state == ScreenState.UTILITIES:
                    self.show_utilities()
                
                elif self.state == ScreenState.SDSF:
                    self.show_sdsf()
                
                else:
                    self.state = ScreenState.MAIN_MENU

        except SystemExit:
            self.send("\nISPF session terminated.\n")
        except Exception as e:
            self.send(f"\nISPF Error: {str(e)}\n")
            logger.error(f"ISPF Error: {str(e)}")
        finally:
            self.send("\nReturning to mainframe...\n")
