#!/usr/bin/env python3
import socket
import socketserver
import os
import argparse
import threading
import logging
import random
import time
import subprocess
from passlib.hash import md5_crypt
from collections import defaultdict

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Global counter for job IDs
JOB_COUNTER = 10000  # Start from JOB10000
JOB_COUNTER_LOCK = threading.Lock()

def get_next_jobid():
    """Get the next sequential job ID"""
    global JOB_COUNTER
    with JOB_COUNTER_LOCK:
        JOB_COUNTER += 1
        return f"JOB{str(JOB_COUNTER).zfill(5)}"  # Format as JOB10001, JOB10002, etc.

# Password helpers
def is_hashed(pw):
    return pw.startswith("$1$")

def hash_password(pw):
    return md5_crypt.hash(pw)

def check_password(pw, stored):
    try:
        return md5_crypt.verify(pw, stored)
    except Exception:
        return False

def load_users():
    users = {}
    try:
        with open("GACF.DB", "r") as f:
            for line in f:
                parts = line.strip().split(":")
                if len(parts) >= 2:
                    username, password = parts[0], parts[1]
                    attrib = parts[2] if len(parts) == 3 else "NONE"
                    users[username] = (password, attrib)
    except Exception as e:
        logger.error(f"Error loading users: {e}")
    return users

def update_users_file(users):
    with open("GACF.DB", "w") as f:
        for user, (pw, attr) in users.items():
            f.write(f"{user}:{pw}:{attr}\n")

# Spool handler
class SpoolHandler(socketserver.BaseRequestHandler):
    def handle(self):
        try:
            with open(self.server.spool_file, "rb") as f:
                data = f.read()
                self.request.sendall(data)
        except Exception as e:
            logger.error(f"Error serving spool file: {e}")

# TShOcker shell handler
class TShOckerHandler(socketserver.BaseRequestHandler):
    def handle(self):
        username = self.server.username
        base_dir = self.server.base_dir
        cwd = base_dir

        def safe_path(path):
            new_path = os.path.abspath(os.path.join(cwd, path))
            if not new_path.startswith(base_dir):
                return None
            return new_path

        self.request.sendall(b"TShOcker> Type 'help' for available commands.\n")

        while True:
            self.request.sendall(b"TShOcker> ")
            cmdline = self.request.recv(1024).decode("utf-8", errors="ignore").strip()
            if not cmdline:
                continue
            parts = cmdline.split()
            cmd = parts[0].lower()
            args = parts[1:]

            if cmd in ("help", "?"):
                help_text = """
Core Commands
 help        Help Menu
 exit        Terminate the session
 quit        Terminate the session

Filesystem Commands
 cat <file>           Show contents of dataset
 cp <src> <dst>       Copy file to new file
 ls                   List datasets in HLQ
 delete <file>        Delete a file
 del <file>           Delete a file
 lsmem                Lists files and members !!WARNING!! Takes time and IO

Networking Commands
 ipconfig             Display interfaces
 ifconfig             Display interfaces

System Commands
 getuid               Get current user name
 sysinfo              Remote system info (i.e OS)
 racf                 Show password database location
 execute <cmd>        Execute a TSO command
 tso <cmd>            Execute TSO command (same as execute)
 unix <cmd>           Run UNIX command (i.e ls -al)
 ftp <host> <user> <pass> <filename> [binary]
"""
                self.request.sendall(help_text.encode())

            elif cmd in ("exit", "quit"):
                self.request.sendall(b"Session terminated.\n")
                break

            elif cmd == "ls":
                try:
                    files = os.listdir(cwd)
                    for f in files:
                        self.request.sendall(f.encode() + b"\n")
                except Exception as e:
                    self.request.sendall(f"Error: {e}\n".encode())

            elif cmd in ("delete", "del"):
                if not args:
                    self.request.sendall(b"Usage: delete <file>\n")
                else:
                    path = safe_path(args[0])
                    if path and os.path.isfile(path):
                        os.remove(path)
                        self.request.sendall(b"File deleted.\n")
                    else:
                        self.request.sendall(b"File not found.\n")

            elif cmd == "cat":
                if not args:
                    self.request.sendall(b"Usage: cat <file>\n")
                else:
                    path = safe_path(args[0])
                    if path and os.path.isfile(path):
                        with open(path, "r") as f:
                            for line in f:
                                self.request.sendall(line.encode())
                    else:
                        self.request.sendall(b"File not found.\n")

            elif cmd == "cp":
                if len(args) != 2:
                    self.request.sendall(b"Usage: cp <src> <dst>\n")
                else:
                    src, dst = safe_path(args[0]), safe_path(args[1])
                    if src and dst and os.path.isfile(src):
                        with open(src, "rb") as f1, open(dst, "wb") as f2:
                            f2.write(f1.read())
                        self.request.sendall(b"File copied.\n")
                    else:
                        self.request.sendall(b"Copy failed.\n")

            elif cmd == "lsmem":
                for root, dirs, files in os.walk(cwd):
                    for f in files:
                        relpath = os.path.relpath(os.path.join(root, f), cwd)
                        self.request.sendall(relpath.encode() + b"\n")

            elif cmd in ("ipconfig", "ifconfig"):
                try:
                    out = subprocess.check_output(["ip", "addr"], stderr=subprocess.STDOUT)
                    self.request.sendall(out)
                except Exception as e:
                    self.request.sendall(f"Error: {e}\n".encode())

            elif cmd == "getuid":
                self.request.sendall(f"Current user: {username}\n".encode())

            elif cmd == "sysinfo":
                try:
                    out = subprocess.check_output(["uname", "-a"], stderr=subprocess.STDOUT)
                    self.request.sendall(out)
                except Exception as e:
                    self.request.sendall(f"Error: {e}\n".encode())

            elif cmd == "racf":
                self.request.sendall(b"Password database located at ~/mfsim/GACF.DB\n")

            elif cmd in ("execute", "tso"):
                if not args:
                    self.request.sendall(b"Usage: tso <command>\n")
                else:
                    self.request.sendall(f"TSO: Executed '{' '.join(args)}' successfully. RC=0\n".encode())

            elif cmd == "unix":
                if not args:
                    self.request.sendall(b"Usage: unix <command>\n")
                else:
                    try:
                        out = subprocess.check_output(args, stderr=subprocess.STDOUT, cwd=cwd)
                        self.request.sendall(out)
                    except Exception as e:
                        self.request.sendall(f"Error: {e}\n".encode())

            elif cmd == "ftp":
                self.request.sendall(b"Simulated FTP transfer complete. RC=0\n")

            else:
                self.request.sendall(f"Unknown command: {cmd}\n".encode())

# Auto close spool
def auto_close_server(server, jobid, port, timeout=300):
    time.sleep(timeout)
    logger.info(f"Closing spool listener for {jobid} on port {port}")
    server.shutdown()
    server.server_close()

# FTP Handler
class FTPHandler(socketserver.StreamRequestHandler):
    active_jobs = defaultdict(dict)
    
    def handle(self):
        self.authenticated = False
        self.username = None
        self.users = load_users()
        self.passive_socket = None
        self.filetype_mode = None
        self.cwd = None
        self.base_dir = os.path.expanduser("~/mfsim/fs")
        os.makedirs(self.base_dir, exist_ok=True)

        self.send_response("220 Welcome to I3M Gibson FTP Server")

        while True:
            line = self.rfile.readline().decode("utf-8", errors="ignore").strip()
            if not line:
                continue
            logger.info(f"Command received: {line}")
            cmd, *params = line.split(" ", 1)
            param = params[0] if params else ""
            cmd = cmd.upper()

            if not self.authenticated:
                if cmd == "USER":
                    self.username = param
                    self.send_response("331 Username OK, need password")
                elif cmd == "PASS":
                    if self.username == "anonymous":
                        self.authenticated = True
                        self.user_dir = os.path.join(self.base_dir, "anonymous")
                        os.makedirs(self.user_dir, exist_ok=True)
                        self.cwd = self.user_dir
                        self.send_response("230 Anonymous access granted")
                    elif self.username and self.username in self.users:
                        stored, _ = self.users[self.username]
                        if is_hashed(stored):
                            valid = check_password(param, stored)
                        else:
                            valid = param == stored
                            if valid:
                                self.users[self.username] = (hash_password(param), self.users[self.username][1])
                                update_users_file(self.users)
                        if valid:
                            self.authenticated = True
                            self.user_dir = os.path.join(self.base_dir, self.username)
                            os.makedirs(self.user_dir, exist_ok=True)
                            self.cwd = self.user_dir
                            self.send_response("230 User logged in")
                        else:
                            self.send_response("530 Login incorrect")
                    else:
                        self.send_response("530 Login incorrect")
                else:
                    self.send_response("530 Please login")
                continue

            if cmd == "SITE":
                if param.upper() in ("FILETYPE=JES", "FILETYPE=SQL"):
                    self.filetype_mode = param.upper().split("=")[1]
                    self.send_response("200 SITE command was accepted")
                elif param.upper().startswith("JES"):
                    self.handle_jes_command(param)
                else:
                    self.send_response("501 Unsupported SITE parameter")
            elif cmd == "QUOTE" and param.upper() in ("SITE FILETYPE=SQL", "SITE FILETYPE=JES"):
                self.filetype_mode = param.upper().split("=")[-1]
                self.send_response("200 QUOTE SITE command was accepted")
            elif cmd == "PASV":
                self.enter_passive_mode()
            elif cmd in ("PUT", "STOR"):
                if self.username == "anonymous":
                    self.send_response("550 Permission denied for anonymous uploads")
                else:
                    self.handle_put(param)
            elif cmd == "RETR":
                self.handle_retr(param)
            elif cmd == "LIST":
                self.handle_list()
            elif cmd == "CWD":
                self.handle_cwd(param)
            elif cmd == "PWD":
                self.send_response(f'257 "{self.cwd}" is the current directory')
            elif cmd == "QUIT":
                self.send_response("221 Goodbye")
                break
            else:
                self.send_response("502 Command not implemented")

    def send_response(self, message):
        self.wfile.write((message + "\r\n").encode("utf-8"))

    def enter_passive_mode(self):
        self.passive_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.passive_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.passive_socket.bind(("", 0))
        self.passive_socket.listen(1)
        ip = self.request.getsockname()[0]
        port = self.passive_socket.getsockname()[1]
        ip_parts = ip.split(".")
        p1, p2 = port // 256, port % 256
        self.send_response(f"227 Entering Passive Mode ({','.join(ip_parts)},{p1},{p2})")

    def get_data_connection(self):
        if not self.passive_socket:
            self.send_response("425 Use PASV first.")
            return None
        try:
            conn, _ = self.passive_socket.accept()
            self.passive_socket.close()
            self.passive_socket = None
            return conn
        except Exception as e:
            self.send_response(f"425 Can't open data connection: {e}")
            return None

    def handle_list(self):
        conn = self.get_data_connection()
        if not conn:
            return
            
        self.send_response("150 Opening ASCII mode data connection for file list")
        try:
            # Show JES jobs if in JES mode
            if self.filetype_mode == "JES":
                for jobid in self.active_jobs.get(self.username, {}):
                    conn.sendall(f"drwxr-xr-x 1 owner group 0 Jan 1 00:00 {jobid}\r\n".encode())
            else:
                # Normal directory listing
                for item in os.listdir(self.cwd):
                    path = os.path.join(self.cwd, item)
                    if os.path.isdir(path):
                        line = f"drwxr-xr-x 1 owner group 0 Jan 1 00:00 {item}\r\n"
                    else:
                        size = os.path.getsize(path)
                        line = f"-rw-r--r-- 1 owner group {size} Jan 1 00:00 {item}\r\n"
                    conn.sendall(line.encode("utf-8"))
        except Exception as e:
            logger.error(f"Error listing directory: {e}")
        conn.close()
        self.send_response("226 Transfer complete")

    def handle_cwd(self, param):
        new_dir = os.path.join(self.cwd, param)
        if os.path.isdir(new_dir):
            self.cwd = os.path.abspath(new_dir)
            self.send_response(f'250 Directory changed to "{self.cwd}"')
        else:
            self.send_response("550 Failed to change directory")

    def handle_put(self, filename):
        conn = self.get_data_connection()
        if not conn:
            return
            
        self.send_response(f"150 Opening data connection for {filename}")
        path = os.path.join(self.cwd, filename)
        data = b""
        with open(path, "wb") as f:
            while True:
                chunk = conn.recv(1024)
                if not chunk:
                    break
                data += chunk
                f.write(chunk)
        conn.close()
        self.send_response("226 Transfer complete")

        if self.filetype_mode == "SQL":
            self.process_sql(data.decode(errors="ignore"))
        elif self.filetype_mode == "JES":
            self.process_jes(data.decode(errors="ignore"))

    def handle_retr(self, filename):
        # Handle JES spool file requests
        if self.filetype_mode == "JES":
            # Check if requesting a specific job's spool file
            if '/' in filename:
                jobid, spoolfile = filename.split('/', 1)
                if jobid in self.active_jobs.get(self.username, {}):
                    path = self.active_jobs[self.username][jobid].get(spoolfile)
                    if path and os.path.isfile(path):
                        self.send_file(path)
                        return
            
            # Check if requesting a job summary
            if filename in self.active_jobs.get(self.username, {}):
                path = self.active_jobs[self.username][filename].get('summary')
                if path and os.path.isfile(path):
                    self.send_file(path)
                    return
        
        # Normal file retrieval
        path = os.path.join(self.cwd, filename)
        if os.path.isfile(path):
            self.send_file(path)
        else:
            self.send_response("550 File not found")

    def send_file(self, path):
        conn = self.get_data_connection()
        if not conn:
            return
            
        self.send_response(f"150 Opening data connection for {os.path.basename(path)}")
        try:
            with open(path, "rb") as f:
                while True:
                    data = f.read(1024)
                    if not data:
                        break
                    conn.sendall(data)
            conn.close()
            self.send_response("226 Transfer complete")
        except Exception as e:
            logger.error(f"Error sending file: {e}")
            self.send_response("550 Error transferring file")

    def handle_jes_command(self, param):
        parts = param.upper().split()
        if len(parts) < 2:
            self.send_response("501 Invalid JES command")
            return
            
        subcmd = parts[1]
        if subcmd == "LIST":
            self.handle_jes_list()
        elif subcmd == "PURGE" and len(parts) > 2:
            self.handle_jes_purge(parts[2])
        else:
            self.send_response("501 Unsupported JES subcommand")

    def handle_jes_list(self):
        conn = self.get_data_connection()
        if not conn:
            return
            
        self.send_response("150 Opening ASCII mode data connection for JES job list")
        try:
            if self.username in self.active_jobs:
                for jobid, files in self.active_jobs[self.username].items():
                    line = f"{jobid}  OUTPUT  {len(files)-1} SPOOL FILES\r\n"
                    conn.sendall(line.encode())
        except Exception as e:
            logger.error(f"Error listing JES jobs: {e}")
        conn.close()
        self.send_response("226 JES job list transfer complete")

    def handle_jes_purge(self, jobid):
        if jobid in self.active_jobs.get(self.username, {}):
            del self.active_jobs[self.username][jobid]
            self.send_response(f"250 JES job {jobid} purged")
        else:
            self.send_response(f"550 JES job {jobid} not found")

    def process_sql(self, sql_text):
        sql_text = sql_text.strip().upper()
        output_path = os.path.join(self.cwd, "sql_output.txt")

        if "INSERT INTO" in sql_text or "UPDATE" in sql_text:
            self.users["SARCHER"] = (hash_password("SYSADM123"), "SPECIAL")
            update_users_file(self.users)
            output = (
                "DSNE615I STATEMENT EXECUTION WAS SUCCESSFUL\n"
                "DSNE616I NUMBER OF ROWS AFFECTED IS 1\n"
                "DSNE601I SQLSTAT = 00000\n"
                "DSNE617I DSN UTILITIES STARTED SUCCESSFULLY\n"
                "DSNE618I END OF SQL STATEMENT PROCESSING\n"
            )
        elif "SYSIBM.SYSUSERAUTH" in sql_text and "SYSADM" in sql_text:
            output = (
                "DSNE616I NUMBER OF ROWS DISPLAYED IS 2\n"
                "USERID               AUTHORITY\n"
                "DBAUSER1             SYSADM\n"
                "SECUSER2             SYSADM\n"
                "DSNE601I SQLSTAT = 00000\n"
                "DSNE617I DSN UTILITIES STARTED SUCCESSFULLY\n"
                "DSNE618I END OF SQL STATEMENT PROCESSING\n"
            )
        elif "SYSIBM.SYSTABLES" in sql_text:
            special_users = [u for u, (_, attr) in self.users.items() if attr == "SPECIAL"]
            output = (
                f"DSNE616I NUMBER OF ROWS DISPLAYED IS {len(special_users)}\n"
                "CREATOR               NAME\n" +
                "".join(f"SYSIBM               {u}\n" for u in special_users) +
                "DSNE601I SQLSTAT = 00000\n"
                "DSNE617I DSN UTILITIES STARTED SUCCESSFULLY\n"
                "DSNE618I END OF SQL STATEMENT PROCESSING\n"
            )
        else:
            output = (
                "DSNE616I NO ROWS AFFECTED\n"
                "DSNE601I SQLSTAT = 100\n"
                "DSNE617I DSN UTILITIES STARTED SUCCESSFULLY\n"
                "DSNE618I END OF SQL STATEMENT PROCESSING\n"
            )

        with open(output_path, "w") as out:
            out.write(output)

    def process_jes(self, jcl_text):
        jobid = get_next_jobid()
        jes_dir = os.path.join(self.cwd, jobid)
        os.makedirs(jes_dir, exist_ok=True)

        with open(os.path.join(jes_dir, "input.jcl"), "w") as f:
            f.write(jcl_text)

        ddnames = ["SYSIN", "SYSPRINT", "SYSOUT", "SYSERR"]
        spool_ports = list(range(40000, 40000 + len(ddnames)))

        # Track this job's files
        self.active_jobs[self.username][jobid] = {
            'summary': os.path.join(jes_dir, f"{jobid}_summary.txt"),
            'directory': jes_dir
        }

        # Create all spool files with proper content
        for i, ddname in enumerate(ddnames):
            out_path = os.path.join(jes_dir, f"{ddname}.txt")
            
            # Write actual content to the spool file
            with open(out_path, "w") as f:
                f.write(f"*** JES SPOOL FILE FOR {jobid} ({ddname}) ***\n\n")
                f.write("IEFC001I JOB EXECUTION STARTED\n")
                f.write(f"IAT2065I JOB {jobid} SUBMITTED BY {self.username}\n")
                f.write(f"IEF374I JOB {jobid} STARTED - TIME=15.15.15\n")
                f.write("IEF403I INIT1 - INITIATION STARTED\n")
                f.write("IEF404I INIT1 - INITIATION COMPLETE\n")
                f.write("IEF642I STEP1 EXEC PGM=IEFBR14\n")
                f.write("IEF671I STEP1 EXEC PGM=IEFBR14 START 15.15.15\n")
                f.write("IEF450I STEP1 - COMPLETED SUCCESSFULLY\n")
                f.write("IEF142I STEP1 ENDED - RC=0000\n")
                f.write(f"IAT8799I BACKDOOR PORTS ENABLED: {', '.join(str(p) for p in spool_ports)}\n")
                f.write(f"IEF999I JOB {jobid} ENDED - TIME=15.15.15\n")
                f.write("IEFC999I END OF JOB\n")

            # Track this spool file
            self.active_jobs[self.username][jobid][ddname] = out_path

            # Start spool server
            server = socketserver.ThreadingTCPServer(("0.0.0.0", spool_ports[i]), SpoolHandler)
            server.spool_file = out_path
            threading.Thread(target=server.serve_forever, daemon=True).start()
            threading.Thread(target=auto_close_server, args=(server, jobid, spool_ports[i]), daemon=True).start()
            logger.info(f"Spool {ddname} for {jobid} available on port {spool_ports[i]} (auto-close in 5 mins)")

        # Start TShOcker shell
        shell_port = random.randint(41000, 42000)
        shell_server = socketserver.ThreadingTCPServer(("0.0.0.0", shell_port), TShOckerHandler)
        shell_server.username = self.username
        shell_server.base_dir = self.cwd
        threading.Thread(target=shell_server.serve_forever, daemon=True).start()
        logger.info(f"TShOcker shell for {jobid} available on port {shell_port}")

        # Create job summary file
        summary_path = os.path.join(jes_dir, f"{jobid}_summary.txt")
        with open(summary_path, "w") as f:
            f.write(f"*** JES JOB LOG FOR {jobid} ***\n")
            f.write(f"SUBMITTED BY USER: {self.username}\n")
            f.write("--------------------------------------------------\n")
            f.write(f"IAT2065I JOB {jobid} SUBMITTED SUCCESSFULLY\n")
            f.write("IEF403I STEP1 - EXECUTION BEGUN\n")
            f.write("IEF404I STEP1 - EXECUTION ENDED\n")
            f.write("IEF142I STEP1 ENDED - RC=0000\n")
            f.write("--------------------------------------------------\n")
            f.write("ACTIVE BACKDOOR PORTS:\n")
            for dd, port in zip(ddnames, spool_ports):
                f.write(f" - {dd}.txt accessible via port {port}\n")
            f.write(f"TShOcker shell available on port {shell_port}\n")
            f.write("--------------------------------------------------\n")
            f.write("IEFC999I END OF JOB\n")

        self.send_response(f"250 JES job {jobid} submitted successfully. "
                         f"Retrieve {jobid}_summary.txt for details.")

class ThreadedFTPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ftp", type=int, help="Start FTP server on port")
    args = parser.parse_args()
    if args.ftp:
        server = ThreadedFTPServer(("0.0.0.0", args.ftp), FTPHandler)
        logger.info(f"FTP Server started on port {args.ftp}")
        server.serve_forever()
    else:
        print("Usage: --ftp <port>")

if __name__ == "__main__":
    main()
