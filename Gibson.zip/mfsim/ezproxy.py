#!/usr/bin/env python3

import socket
import threading
import argparse
import logging
import sys

def setup_logger(logfile=None):
    logger = logging.getLogger("ezproxy")
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s')
    handler = logging.StreamHandler(sys.stdout) if not logfile else logging.FileHandler(logfile)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger

def ascii_to_ebcdic(data, ebcdic_codec="cp037"):
    try:
        return data.decode('ascii', errors='replace').encode(ebcdic_codec)
    except Exception:
        return data

def ebcdic_to_ascii(data, ebcdic_codec="cp037"):
    try:
        return data.decode(ebcdic_codec, errors='replace').encode('ascii', errors='replace')
    except Exception:
        return data

def forward(src, dst, direction, convert=None, ebcdic_codec="cp037", logger=None):
    try:
        while True:
            data = src.recv(4096)
            if not data:
                break
            if convert == "to_ebcdic":
                data = ascii_to_ebcdic(data, ebcdic_codec)
                if logger: logger.info(f"{direction}: {len(data)} bytes (ASCII→EBCDIC)")
            elif convert == "to_ascii":
                data = ebcdic_to_ascii(data, ebcdic_codec)
                if logger: logger.info(f"{direction}: {len(data)} bytes (EBCDIC→ASCII)")
            else:
                if logger: logger.info(f"{direction}: {len(data)} bytes (raw)")
            dst.sendall(data)
    except Exception as e:
        if logger: logger.warning(f"{direction}: Exception: {e}")
    finally:
        try: src.shutdown(socket.SHUT_RD)
        except: pass
        try: dst.shutdown(socket.SHUT_WR)
        except: pass

def handle_client(local_conn, remote_host, remote_port, lport, ebcdic_ports, ebcdic_codec, logger):
    remote_info = f"{remote_host}:{remote_port}"
    convert = lport in ebcdic_ports
    try:
        remote_conn = socket.create_connection((remote_host, remote_port))
        logger.info(f"Connected local port {lport} -> {remote_info} (EBCDIC: {convert})")
    except Exception as e:
        logger.error(f"Failed to connect to {remote_info}: {e}")
        local_conn.close()
        return

    t1 = threading.Thread(
        target=forward,
        args=(local_conn, remote_conn, f"{lport}->{remote_info}", "to_ebcdic" if convert else None, ebcdic_codec, logger),
        daemon=True
    )
    t2 = threading.Thread(
        target=forward,
        args=(remote_conn, local_conn, f"{remote_info}->{lport}", "to_ascii" if convert else None, ebcdic_codec, logger),
        daemon=True
    )
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    local_conn.close()
    remote_conn.close()
    logger.info(f"Session closed: {lport} <--> {remote_info}")

def proxy_server(local_port, remote_host, remote_port, ebcdic_ports, ebcdic_codec, logger):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(('0.0.0.0', local_port))
        s.listen(5)
        logger.info(f"Listening on 0.0.0.0:{local_port}, forwarding to {remote_host}:{remote_port}")
        while True:
            try:
                client_conn, addr = s.accept()
                logger.info(f"Accepted connection from {addr} on local port {local_port}")
                threading.Thread(
                    target=handle_client,
                    args=(client_conn, remote_host, remote_port, local_port, ebcdic_ports, ebcdic_codec, logger),
                    daemon=True
                ).start()
            except Exception as e:
                logger.error(f"Accept failed on port {local_port}: {e}")

def main():
    parser = argparse.ArgumentParser(description="Multi-port TCP proxy with optional EBCDIC<->ASCII conversion")
    parser.add_argument('--local', nargs='+', type=int, required=True,
                        help='Local ports to listen on')
    parser.add_argument('--remote-host', type=str, required=True,
                        help='Remote host to forward to')
    parser.add_argument('--ports', nargs='+', type=int, required=True,
                        help='Remote ports to forward to')
    parser.add_argument('--ebcdic', nargs='*', type=int, default=[],
                        help='Local ports to convert: ASCII<->EBCDIC')
    parser.add_argument('--ebcdic-codec', type=str, default="cp037",
                        help='Python EBCDIC codec to use (default: cp037)')
    parser.add_argument('--logfile', type=str, default=None,
                        help='Path to log file (default: stdout)')
    args = parser.parse_args()

    logger = setup_logger(args.logfile)

    if len(args.local) != len(args.ports):
        logger.error("Number of --local ports must match number of --ports.")
        exit(1)

    ebcdic_ports = set(args.ebcdic)

    for lport, rport in zip(args.local, args.ports):
        threading.Thread(
            target=proxy_server,
            args=(lport, args.remote_host, rport, ebcdic_ports, args.ebcdic_codec, logger),
            daemon=True
        ).start()

    try:
        while True:
            threading.Event().wait(3600)
    except KeyboardInterrupt:
        logger.info("Shutting down proxy.")

if __name__ == '__main__':
    main()
