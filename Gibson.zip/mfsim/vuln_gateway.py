from flask import Flask, request
import requests

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    html = """
        <form method='post'>
            User: <input name='user'><br>
            Password: <input name='password'><br>
            SQL: <input name='sql'><br>
            <input type='submit'>
        </form>
    """
    if request.method == "POST":
        user = request.form["user"]
        password = request.form["password"]
        sql = request.form["sql"]
        r = requests.post("http://0.0.0.0:8081/query", json={
            "user": user,
            "password": password,
            "sql": sql
        })
        return html + "<pre>" + r.text + "</pre>"
    return html

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8081)
