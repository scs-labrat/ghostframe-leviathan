import curses
import os
from datetime import datetime

# Store the initial (top-level) directory.
INITIAL_DIRECTORY = os.getcwd()

# --- Screen and layout constants ---
SCREEN_WIDTH = 80
SCREEN_LINES = 24

# Editor screen layout
DATA_AREA_START = 3           # rows 3 to 22 (20 rows)
DATA_ROWS = 20
COMMAND_FIELD_WIDTH = 6       # first 6 columns
TEXT_FIELD_WIDTH = 74         # remaining columns (80 - 6)
DEFAULT_CMD_FIELD = "''''''"   # default command field for editor

# Directory panel layout constants
LISTING_CMD_WIDTH = 1         # command field width (a single quote)
FILENAME_WIDTH   = 30         # file name column width
VOLUME_WIDTH     = 8          # VOLUME column width
ALTRK_WIDTH      = 5          # ALTRK column width
ORG_WIDTH        = 5          # ORG column width
FRMT_WIDTH       = 5          # FRMT column width
BLKSZ_WIDTH      = 8          # BLKSZ column width

LISTING_HEADER_ROW = 2        # header row for the directory panel
LISTING_START_ROW  = 3        # listing starts on row 3
DEFAULT_LISTING_CMD_FIELD = "'"  # default command field for directory panel

# --- File I/O functions ---
def load_file(filename):
    if os.path.exists(filename):
        with open(filename, "r") as f:
            return f.read().splitlines()
    return []

def save_file(filename, file_lines):
    try:
        with open(filename, "w") as f:
            f.write("\n".join(file_lines))
    except Exception as e:
        return f"Error saving file: {e}"
    return "File saved."

# --- FIND function ---
def perform_find(keyword, file_lines):
    for idx, line in enumerate(file_lines):
        pos = line.find(keyword)
        if pos != -1:
            return idx, pos
    return None

# --- DSINFO Screen ---
def dsinfo_screen(stdscr, filename):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    dsinfo_path = os.path.join(script_dir, "DSINFO.TXT")
    
    curses.curs_set(0)
    curses.start_color()
    curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
    stdscr.bkgd(' ', curses.color_pair(1))
    stdscr.clear()
    try:
        with open(dsinfo_path, "r") as f:
            content = f.read()
    except Exception:
        content = "DSINFO.TXT not found."
    current_date = datetime.now().strftime("%Y-%m-%d")
    content = content.replace("filename", filename)
    content = content.replace("D4TE", current_date)
    lines = content.splitlines()
    for i, line in enumerate(lines):
        if i >= SCREEN_LINES:
            break
        stdscr.addstr(i, 0, line[:SCREEN_WIDTH])
    stdscr.refresh()
    stdscr.getch()

# --- DSDEL Screen ---
def dsdel_screen(stdscr, filename):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    dsdel_path = os.path.join(script_dir, "DSDEL.TXT")
    
    curses.curs_set(0)
    curses.start_color()
    curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)   # Default green
    curses.init_pair(2, curses.COLOR_YELLOW, curses.COLOR_BLACK)  # Yellow for deletion info
    stdscr.bkgd(' ', curses.color_pair(1))
    stdscr.clear()
    try:
        with open(dsdel_path, "r") as f:
            content = f.read()
    except Exception:
        content = "DSDEL.TXT not found."
    current_date = datetime.now().strftime("%Y-%m-%d")
    content = content.replace("filename", filename)
    content = content.replace("D4TE", current_date)
    lines = content.splitlines()
    row = 0
    for line in lines:
        if "DELETION INFORMATION" in line:
            start_index = line.find("DELETION INFORMATION")
            before = line[:start_index]
            after = line[start_index + len("DELETION INFORMATION"):]
            stdscr.addstr(row, 0, before, curses.color_pair(1))
            stdscr.addstr(row, len(before), "DELETION INFORMATION", curses.color_pair(2))
            stdscr.addstr(row, len(before) + len("DELETION INFORMATION"), after, curses.color_pair(1))
        else:
            stdscr.addstr(row, 0, line, curses.color_pair(1))
        row += 1
        if row >= SCREEN_LINES:
            break
    stdscr.refresh()
    while True:
        key = stdscr.getch()
        if key == curses.KEY_F3:
            return  # Cancel deletion.
        elif key in (curses.KEY_ENTER, 10, 13):
            try:
                os.remove(filename)
            except Exception as e:
                stdscr.clear()
                err_msg = f"Error deleting {filename}: {str(e)}"
                stdscr.addstr(SCREEN_LINES//2, (SCREEN_WIDTH - len(err_msg))//2, err_msg, curses.color_pair(1))
                stdscr.refresh()
                stdscr.getch()
                return
            box_height = 3
            box_width = 30
            start_y = (SCREEN_LINES - box_height) // 2
            start_x = (SCREEN_WIDTH - box_width) // 2
            win = curses.newwin(box_height, box_width, start_y, start_x)
            win.bkgd(' ', curses.color_pair(1))
            win.box()
            msg = "DATASET DELETED"
            win.addstr(1, (box_width - len(msg)) // 2, msg, curses.color_pair(1))
            win.refresh()
            stdscr.refresh()
            stdscr.getch()
            return

# --- Editor Screen Functions ---
def draw_screen(stdscr, file_lines, top_line_index, filename, global_cmd_buffer, data_cmd_buffers, cur_row, cur_col, find_result):
    stdscr.clear()
    header_text = f"eZedit - 1.00   {filename}"
    header = header_text.ljust(40) + f"COLUMNS {cur_row+1} {cur_col+1}"
    stdscr.addstr(0, 0, header[:SCREEN_WIDTH])
    global_label = "Command ===>"
    stdscr.addstr(1, 0, global_label)
    stdscr.addstr(1, 13, global_cmd_buffer.ljust(40))
    scroll_text = "Scroll ===> CSR"
    stdscr.addstr(1, 56, scroll_text)
    top_marker = "****** ****ZAP****AUTOSAVE********** TOP OF DATA *******************************"
    stdscr.addstr(2, 0, top_marker[:SCREEN_WIDTH])
    for row in range(DATA_AREA_START, DATA_AREA_START + DATA_ROWS):
        file_index = top_line_index + (row - DATA_AREA_START)
        raw_cmd = data_cmd_buffers.get(row, "")
        cmd_field = DEFAULT_CMD_FIELD if raw_cmd == "" else raw_cmd.ljust(COMMAND_FIELD_WIDTH)
        stdscr.addstr(row, 0, cmd_field[:COMMAND_FIELD_WIDTH])
        text = file_lines[file_index] if file_index < len(file_lines) else ""
        if (find_result is not None) and (file_index == find_result[0]):
            # Use the stored starting offset, then extend to cover the whole word.
            pos = find_result[1]
            # Extend end to cover entire word.
            end = pos
            while end < len(text) and text[end].isalnum():
                end += 1
            before = text[:pos]
            match = text[pos:end]
            after = text[end:]
            stdscr.addstr(row, COMMAND_FIELD_WIDTH, before)
            stdscr.addstr(row, COMMAND_FIELD_WIDTH + len(before), match, curses.color_pair(3))
            stdscr.addstr(row, COMMAND_FIELD_WIDTH + len(before) + len(match),
                          after.ljust(TEXT_FIELD_WIDTH - len(before) - len(match)))
        else:
            stdscr.addstr(row, COMMAND_FIELD_WIDTH, text[:TEXT_FIELD_WIDTH].ljust(TEXT_FIELD_WIDTH))
    bottom_marker = "****** ****ZAP****AUTOSAVE********* BOTTOM OF DATA ****************** 6928K FREE"
    stdscr.addstr(SCREEN_LINES - 1, 0, bottom_marker[:SCREEN_WIDTH])
    stdscr.refresh()

def ensure_file_line(file_lines, file_index):
    while len(file_lines) <= file_index:
        file_lines.append("")

def process_data_command(cmd, file_lines, file_index, top_line_index, stdscr, copy_buffer):
    if not cmd:
        return
    letter = cmd[0].lower()
    if letter == 'i':
        try:
            num = int(cmd[1:]) if len(cmd) > 1 else 1
        except ValueError:
            num = 1
        for _ in range(num):
            file_lines.insert(file_index, "")
        stdscr.addstr(SCREEN_LINES - 1, 0, f"Inserted {num} blank line(s).".ljust(SCREEN_WIDTH))
        stdscr.getch()
    elif letter == 'd':
        try:
            num = int(cmd[1:]) if len(cmd) > 1 else 1
        except ValueError:
            num = 1
        deleted = 0
        for _ in range(num):
            if file_index < len(file_lines):
                del file_lines[file_index]
                deleted += 1
        stdscr.addstr(SCREEN_LINES - 1, 0, f"Deleted {deleted} line(s).".ljust(SCREEN_WIDTH))
        stdscr.getch()
    elif letter == 'c':
        try:
            num = int(cmd[1:]) if len(cmd) > 1 else 1
        except ValueError:
            num = 1
        copy_buffer.clear()
        copy_buffer.extend(file_lines[file_index:file_index + num])
        stdscr.addstr(SCREEN_LINES - 1, 0, f"Copied {len(copy_buffer)} line(s) into buffer.".ljust(SCREEN_WIDTH))
        stdscr.getch()
    elif letter == 'p':
        try:
            count = int(cmd[1:]) if len(cmd) > 1 else 1
        except ValueError:
            count = 1
        if not copy_buffer:
            stdscr.addstr(SCREEN_LINES - 1, 0, "Nothing to paste.".ljust(SCREEN_WIDTH))
            stdscr.getch()
        else:
            for _ in range(count):
                for i, line in enumerate(copy_buffer):
                    file_lines.insert(file_index + i, line)
            stdscr.addstr(SCREEN_LINES - 1, 0, f"Pasted buffer {count} time(s).".ljust(SCREEN_WIDTH))
            stdscr.getch()

# --- Directory Panel Functions ---
def draw_directory_panel(stdscr, file_list, top_index, global_cmd_buffer, global_cmd_cursor, listing_cmd_buffers, listing_cursor):
    stdscr.clear()
    header_text = "ISPF Directory Panel"
    instructions = "TAB: Toggle Focus | ENTER: Edit file/Show Dir, DSINFO (S) or DSDEL (D) | F3: Back"
    header = header_text.ljust(40) + instructions
    stdscr.addstr(0, 0, header[:SCREEN_WIDTH])
    global_label = "Command ===>"
    stdscr.addstr(1, 0, global_label)
    stdscr.addstr(1, 13, global_cmd_buffer.ljust(40))
    scroll_text = "Scroll ===> CSR"
    stdscr.addstr(1, 56, scroll_text)
    col = 0
    stdscr.addstr(LISTING_HEADER_ROW, col, " " * LISTING_CMD_WIDTH)
    col += LISTING_CMD_WIDTH + 1
    stdscr.addstr(LISTING_HEADER_ROW, col, "FILE".ljust(FILENAME_WIDTH))
    col += FILENAME_WIDTH + 1
    stdscr.addstr(LISTING_HEADER_ROW, col, "VOLUME".ljust(VOLUME_WIDTH))
    col += VOLUME_WIDTH + 1
    stdscr.addstr(LISTING_HEADER_ROW, col, "ALTRK".ljust(ALTRK_WIDTH))
    col += ALTRK_WIDTH + 1
    stdscr.addstr(LISTING_HEADER_ROW, col, "ORG".ljust(ORG_WIDTH))
    col += ORG_WIDTH + 1
    stdscr.addstr(LISTING_HEADER_ROW, col, "FRMT".ljust(FRMT_WIDTH))
    col += FRMT_WIDTH + 1
    stdscr.addstr(LISTING_HEADER_ROW, col, "BLKSZ".ljust(BLKSZ_WIDTH))
    for row in range(LISTING_START_ROW, LISTING_START_ROW + DATA_ROWS):
        file_index = top_index + (row - LISTING_START_ROW)
        if file_index < len(file_list):
            cmd_buf = listing_cmd_buffers.get(row, "")
            cmd_field = DEFAULT_LISTING_CMD_FIELD if cmd_buf == "" else cmd_buf.ljust(LISTING_CMD_WIDTH)
            file_name = file_list[file_index].upper()
            volume = "WORK01"
            if os.path.isdir(file_list[file_index]):
                altrk = "15"
                org = "PS"
                blksz = ""
            else:
                altrk = "10"
                org = "PO"
                try:
                    size = os.stat(file_list[file_index]).st_size
                    blksz = str(((size + 79) // 80) * 80)
                except Exception:
                    blksz = ""
            frmt = "FB"
            row_str = (cmd_field.ljust(LISTING_CMD_WIDTH) + " " +
                       file_name.ljust(FILENAME_WIDTH) + " " +
                       volume.ljust(VOLUME_WIDTH) + " " +
                       altrk.ljust(ALTRK_WIDTH) + " " +
                       org.ljust(ORG_WIDTH) + " " +
                       frmt.ljust(FRMT_WIDTH) + " " +
                       blksz.ljust(BLKSZ_WIDTH))
            if (row - LISTING_START_ROW) == listing_cursor:
                stdscr.addstr(row, 0, row_str, curses.A_REVERSE)
            else:
                stdscr.addstr(row, 0, row_str)
        else:
            blank_row = (DEFAULT_LISTING_CMD_FIELD.ljust(LISTING_CMD_WIDTH) + " " +
                         "".ljust(FILENAME_WIDTH) + " " +
                         "".ljust(VOLUME_WIDTH) + " " +
                         "".ljust(ALTRK_WIDTH) + " " +
                         "".ljust(ORG_WIDTH) + " " +
                         "".ljust(FRMT_WIDTH) + " " +
                         "".ljust(BLKSZ_WIDTH))
            stdscr.addstr(row, 0, blank_row)
    footer = "F3: Back   TAB: Toggle Focus"
    stdscr.addstr(SCREEN_LINES - 1, 0, footer.ljust(SCREEN_WIDTH))
    stdscr.refresh()

def directory_panel(stdscr):
    curses.curs_set(1)
    stdscr.keypad(True)
    curses.start_color()
    curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
    stdscr.bkgd(' ', curses.color_pair(1))
    
    file_list = sorted(os.listdir('.'))
    top_index = 0
    global_cmd_buffer = ""
    global_cmd_cursor = 0
    listing_cmd_buffers = {row: "" for row in range(LISTING_START_ROW, LISTING_START_ROW + DATA_ROWS)}
    listing_cursor = 0
    current_mode = "global"
    if current_mode == "global":
        cur_row = 1
        cur_col = 13 + global_cmd_cursor
    else:
        cur_row = LISTING_START_ROW + listing_cursor
        cur_col = 0

    while True:
        draw_directory_panel(stdscr, file_list, top_index, global_cmd_buffer, global_cmd_cursor, listing_cmd_buffers, listing_cursor)
        stdscr.move(cur_row, cur_col)
        key = stdscr.getch()
        
        # F3: If in a sub-directory, go up one level; otherwise exit.
        if key == curses.KEY_F3:
            if os.getcwd() != INITIAL_DIRECTORY:
                os.chdir("..")
                file_list = sorted(os.listdir('.'))
                top_index = 0
                listing_cursor = 0
            else:
                break

        if key == 9:  # TAB toggles focus.
            if current_mode == "global":
                current_mode = "listing"
                cur_row = LISTING_START_ROW + listing_cursor
                cur_col = 0
            else:
                current_mode = "global"
                cur_row = 1
                cur_col = 13 + global_cmd_cursor
            continue
        
        if current_mode == "global":
            if key in (curses.KEY_ENTER, 10, 13):
                cmd = global_cmd_buffer.strip()
                if cmd.upper() == "SAVE":
                    if os.getcwd() != INITIAL_DIRECTORY:
                        os.chdir("..")
                        file_list = sorted(os.listdir('.'))
                        top_index = 0
                        listing_cursor = 0
                    global_cmd_buffer = ""
                    global_cmd_cursor = 0
                    cur_col = 13 + global_cmd_cursor
                    continue
                elif cmd.upper().startswith("E"):
                    parts = cmd.split(maxsplit=1)
                    filename = parts[1].strip() if len(parts) > 1 else ""
                    if filename == "":
                        stdscr.addstr(SCREEN_LINES - 1, 0, "No filename provided.".ljust(SCREEN_WIDTH))
                        stdscr.getch()
                    else:
                        editor_screen(stdscr, filename)
                        file_list = sorted(os.listdir('.'))
                global_cmd_buffer = ""
                global_cmd_cursor = 0
                cur_col = 13 + global_cmd_cursor
                continue
            elif key in (curses.KEY_BACKSPACE, 127):
                if global_cmd_cursor > 0:
                    global_cmd_buffer = global_cmd_buffer[:global_cmd_cursor-1] + global_cmd_buffer[global_cmd_cursor:]
                    global_cmd_cursor -= 1
                    cur_col = 13 + global_cmd_cursor
            elif key in (curses.KEY_LEFT, curses.KEY_RIGHT):
                if key == curses.KEY_LEFT and global_cmd_cursor > 0:
                    global_cmd_cursor -= 1
                elif key == curses.KEY_RIGHT and global_cmd_cursor < len(global_cmd_buffer):
                    global_cmd_cursor += 1
                cur_col = 13 + global_cmd_cursor
            elif key in (curses.KEY_UP, curses.KEY_DOWN):
                current_mode = "listing"
                cur_row = LISTING_START_ROW + listing_cursor
                cur_col = 0
            else:
                if 32 <= key <= 126:
                    ch = chr(key)
                    global_cmd_buffer = global_cmd_buffer[:global_cmd_cursor] + ch + global_cmd_buffer[global_cmd_cursor:]
                    global_cmd_cursor += 1
                    cur_col = 13 + global_cmd_cursor
            continue
        
        if current_mode == "listing":
            file_index = top_index + (cur_row - LISTING_START_ROW)
            if key in (curses.KEY_ENTER, 10, 13):
                cmd = listing_cmd_buffers.get(LISTING_START_ROW + listing_cursor, "").strip()
                if cmd.upper() == "E":
                    if file_index < len(file_list):
                        filename = file_list[file_index]
                        if os.path.isdir(filename):
                            os.chdir(filename)
                            file_list = sorted(os.listdir('.'))
                            top_index = 0
                            listing_cursor = 0
                        else:
                            editor_screen(stdscr, filename)
                            file_list = sorted(os.listdir('.'))
                elif cmd.upper() == "S":
                    if file_index < len(file_list):
                        filename = file_list[file_index]
                        dsinfo_screen(stdscr, filename)
                        file_list = sorted(os.listdir('.'))
                elif cmd.upper() == "D":
                    if file_index < len(file_list):
                        filename = file_list[file_index]
                        dsdel_screen(stdscr, filename)
                        file_list = sorted(os.listdir('.'))
                listing_cmd_buffers[LISTING_START_ROW + listing_cursor] = ""
                cur_col = 0
                continue
            elif key in (curses.KEY_BACKSPACE, 127):
                buf = listing_cmd_buffers.get(LISTING_START_ROW + listing_cursor, "")
                pos = cur_col
                if pos > 0:
                    buf = buf[:pos-1] + buf[pos:]
                    cur_col -= 1
                listing_cmd_buffers[LISTING_START_ROW + listing_cursor] = buf
            elif key in (curses.KEY_LEFT, curses.KEY_RIGHT):
                buf = listing_cmd_buffers.get(LISTING_START_ROW + listing_cursor, "")
                pos = cur_col
                if key == curses.KEY_LEFT and pos > 0:
                    pos -= 1
                elif key == curses.KEY_RIGHT and pos < len(buf):
                    pos += 1
                cur_col = pos
                listing_cmd_buffers[LISTING_START_ROW + listing_cursor] = buf
            elif key in (curses.KEY_UP, curses.KEY_DOWN):
                if key == curses.KEY_UP:
                    if listing_cursor > 0:
                        listing_cursor -= 1
                        cur_row = LISTING_START_ROW + listing_cursor
                        cur_col = 0
                    else:
                        if top_index > 0:
                            top_index -= 1
                elif key == curses.KEY_DOWN:
                    if top_index + listing_cursor + 1 < len(file_list) and listing_cursor < DATA_ROWS - 1:
                        listing_cursor += 1
                        cur_row = LISTING_START_ROW + listing_cursor
                        cur_col = 0
                    else:
                        if top_index + DATA_ROWS < len(file_list):
                            top_index += 1
                continue
            else:
                if 32 <= key <= 126:
                    buf = listing_cmd_buffers.get(LISTING_START_ROW + listing_cursor, "")
                    pos = cur_col
                    buf = buf[:pos] + chr(key) + buf[pos:]
                    listing_cmd_buffers[LISTING_START_ROW + listing_cursor] = buf
                    cur_col += 1
            continue

def editor_screen(stdscr, filename):
    curses.curs_set(1)
    stdscr.keypad(True)
    curses.start_color()
    curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
    # Initialize color pair 3 for yellow highlighting.
    curses.init_pair(3, curses.COLOR_YELLOW, curses.COLOR_BLACK)
    stdscr.bkgd(' ', curses.color_pair(1))
    
    file_lines = load_file(filename)
    top_line_index = 0
    global_cmd_buffer = ""
    global_cmd_cursor = 0
    data_cmd_buffers = {row: "" for row in range(DATA_AREA_START, DATA_AREA_START + DATA_ROWS)}
    copy_buffer = []
    find_result = None
    cur_row, cur_col = 1, 13
    while True:
        draw_screen(stdscr, file_lines, top_line_index, filename, global_cmd_buffer, data_cmd_buffers, cur_row, cur_col, find_result)
        stdscr.move(cur_row, cur_col)
        key = stdscr.getch()
        if key in (curses.KEY_F3, curses.KEY_F7, curses.KEY_F8):
            if key == curses.KEY_F3:
                break
            elif key == curses.KEY_F7:
                top_line_index = max(0, top_line_index - DATA_ROWS)
                continue
            elif key == curses.KEY_F8:
                if top_line_index + DATA_ROWS < len(file_lines):
                    top_line_index += DATA_ROWS
                continue
        if cur_row == 1:
            if key == 9:
                cur_row = DATA_AREA_START
                cur_col = 0
                continue
            if key in (curses.KEY_ENTER, 10, 13):
                cmd = global_cmd_buffer.strip()
                if cmd.upper() == "SAVE":
                    msg = save_file(filename, file_lines)
                    stdscr.addstr(SCREEN_LINES - 1, 0, msg.ljust(SCREEN_WIDTH))
                    stdscr.getch()
                    find_result = None
                elif cmd.upper() == "END":
                    break
                elif cmd.upper().startswith("FIND "):
                    keyword = cmd[5:].strip()
                    result = perform_find(keyword, file_lines)
                    if result is None:
                        stdscr.addstr(SCREEN_LINES - 1, 0, "Keyword not found.".ljust(SCREEN_WIDTH))
                        stdscr.getch()
                        find_result = None
                    else:
                        found_index, found_offset = result
                        # Adjust found_offset to the start of the word.
                        line_text = file_lines[found_index]
                        while found_offset > 0 and line_text[found_offset - 1].isalnum():
                            found_offset -= 1
                        if found_index < top_line_index:
                            top_line_index = found_index
                        elif found_index >= top_line_index + DATA_ROWS:
                            top_line_index = found_index - DATA_ROWS + 1
                        cur_row = DATA_AREA_START + (found_index - top_line_index)
                        cur_col = COMMAND_FIELD_WIDTH + found_offset
                        find_result = (found_index, found_offset, keyword)
                elif cmd.upper() == "TOP":
                    top_line_index = 0
                    cur_row = DATA_AREA_START
                    cur_col = COMMAND_FIELD_WIDTH
                elif cmd.upper() == "BOTTOM":
                    if file_lines:
                        top_line_index = max(0, len(file_lines) - DATA_ROWS)
                        cur_row = DATA_AREA_START + min(DATA_ROWS - 1, len(file_lines) - top_line_index - 1)
                        cur_col = COMMAND_FIELD_WIDTH
                else:
                    find_result = None
                global_cmd_buffer = ""
                global_cmd_cursor = 0
                cur_col = 13
            elif key in (curses.KEY_BACKSPACE, 127):
                if global_cmd_cursor > 0:
                    global_cmd_buffer = global_cmd_buffer[:global_cmd_cursor-1] + global_cmd_buffer[global_cmd_cursor:]
                    global_cmd_cursor -= 1
                    cur_col = 13 + global_cmd_cursor
            elif key in (curses.KEY_LEFT, curses.KEY_RIGHT):
                if key == curses.KEY_LEFT and global_cmd_cursor > 0:
                    global_cmd_cursor -= 1
                elif key == curses.KEY_RIGHT and global_cmd_cursor < len(global_cmd_buffer):
                    global_cmd_cursor += 1
                cur_col = 13 + global_cmd_cursor
            elif key in (curses.KEY_UP, curses.KEY_DOWN):
                cur_row = DATA_AREA_START
                cur_col = 0
            else:
                if 32 <= key <= 126:
                    ch = chr(key)
                    global_cmd_buffer = global_cmd_buffer[:global_cmd_cursor] + ch + global_cmd_buffer[global_cmd_cursor:]
                    global_cmd_cursor += 1
                    cur_col = 13 + global_cmd_cursor
            continue
        if DATA_AREA_START <= cur_row < DATA_AREA_START + DATA_ROWS:
            file_index = top_line_index + (cur_row - DATA_AREA_START)
            ensure_file_line(file_lines, file_index)
            if cur_col < COMMAND_FIELD_WIDTH:
                buffer = data_cmd_buffers.get(cur_row, "")
                pos = cur_col
                if key == 9:
                    cur_col = COMMAND_FIELD_WIDTH
                    continue
                if key in (curses.KEY_ENTER, 10, 13):
                    if buffer.strip() != "":
                        process_data_command(buffer.strip(), file_lines, file_index, top_line_index, stdscr, copy_buffer)
                    data_cmd_buffers[cur_row] = ""
                    cur_col = COMMAND_FIELD_WIDTH
                elif key in (curses.KEY_BACKSPACE, 127):
                    if pos > 0:
                        buffer = buffer[:pos-1] + buffer[pos:]
                        pos -= 1
                    data_cmd_buffers[cur_row] = buffer
                    cur_col = pos
                elif key in (curses.KEY_LEFT, curses.KEY_RIGHT):
                    if key == curses.KEY_LEFT and pos > 0:
                        pos -= 1
                    elif key == curses.KEY_RIGHT and pos < len(buffer):
                        pos += 1
                    cur_col = pos
                    data_cmd_buffers[cur_row] = buffer
                elif key in (curses.KEY_UP, curses.KEY_DOWN):
                    if key == curses.KEY_UP and cur_row > DATA_AREA_START:
                        cur_row -= 1
                    elif key == curses.KEY_DOWN and cur_row < DATA_AREA_START + DATA_ROWS - 1:
                        cur_row += 1
                    if cur_col >= COMMAND_FIELD_WIDTH:
                        cur_col = COMMAND_FIELD_WIDTH - 1
                else:
                    if 32 <= key <= 126:
                        ch = chr(key)
                        if buffer == DEFAULT_CMD_FIELD:
                            buffer = ""
                        if len(buffer) < COMMAND_FIELD_WIDTH:
                            buffer = buffer[:pos] + ch + buffer[pos:]
                            pos += 1
                        data_cmd_buffers[cur_row] = buffer
                        cur_col = pos
                continue
            else:
                ensure_file_line(file_lines, file_index)
                text = file_lines[file_index]
                pos = cur_col - COMMAND_FIELD_WIDTH
                if key == 9:
                    cur_row = 1
                    cur_col = 13 + len(global_cmd_buffer)
                    continue
                if key in (curses.KEY_ENTER, 10, 13):
                    file_lines[file_index] = text[:TEXT_FIELD_WIDTH]
                    if cur_row < DATA_AREA_START + DATA_ROWS - 1:
                        cur_row += 1
                        cur_col = COMMAND_FIELD_WIDTH
                    else:
                        cur_col = COMMAND_FIELD_WIDTH
                elif key in (curses.KEY_BACKSPACE, 127):
                    if pos > 0:
                        text = text[:pos-1] + text[pos:]
                        pos -= 1
                    file_lines[file_index] = text
                    cur_col = COMMAND_FIELD_WIDTH + pos
                elif key in (curses.KEY_LEFT, curses.KEY_RIGHT):
                    if key == curses.KEY_LEFT and pos > 0:
                        pos -= 1
                    elif key == curses.KEY_RIGHT and pos < len(text):
                        pos += 1
                    cur_col = COMMAND_FIELD_WIDTH + pos
                elif key in (curses.KEY_UP, curses.KEY_DOWN):
                    if key == curses.KEY_UP and cur_row > DATA_AREA_START:
                        cur_row -= 1
                        if cur_col < COMMAND_FIELD_WIDTH:
                            cur_col = COMMAND_FIELD_WIDTH
                    elif key == curses.KEY_DOWN and cur_row < DATA_AREA_START + DATA_ROWS - 1:
                        cur_row += 1
                        if cur_col < COMMAND_FIELD_WIDTH:
                            cur_col = COMMAND_FIELD_WIDTH
                else:
                    if 32 <= key <= 126:
                        ch = chr(key)
                        if len(text) < TEXT_FIELD_WIDTH:
                            text = text[:pos] + ch + text[pos:]
                            pos += 1
                        file_lines[file_index] = text
                        cur_col = COMMAND_FIELD_WIDTH + pos
                continue
        if key in (curses.KEY_UP, curses.KEY_DOWN, curses.KEY_LEFT, curses.KEY_RIGHT):
            if key == curses.KEY_UP and cur_row > 0:
                cur_row -= 1
            elif key == curses.KEY_DOWN and cur_row < SCREEN_LINES - 1:
                cur_row += 1
            elif key == curses.KEY_LEFT and cur_col > 0:
                cur_col -= 1
            elif key == curses.KEY_RIGHT and cur_col < SCREEN_WIDTH - 1:
                cur_col += 1

def main(stdscr):
    stdscr.keypad(True)
    while True:
        directory_panel(stdscr)
        stdscr.clear()
        stdscr.addstr(0, 0, "Back to Directory Panel. Press any key to continue or 'q' to quit.")
        key = stdscr.getch()
        if key in (ord('q'), ord('Q')):
            break

if __name__ == "__main__":
    curses.wrapper(main)
