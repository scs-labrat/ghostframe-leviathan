This is just a space where you can practice using the editor.
It will improve once we get beyond the initial Alpha version.

